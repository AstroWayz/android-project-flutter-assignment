package com.technion.android.hellome.android_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
